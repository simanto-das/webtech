<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<footer>
<?php
echo "
<p><h2> Sports E-commerce</h2></p>
<p>Copyright &copy; 1999-" . date("Y") . "</p>";
?>

<div>
	<a href="www.facebook.com">Visit Our Facebook</a>
	<a href="www.instagram.com">Visit Our Instagram</a>
	<a href="www.twitter.com">Visit Our Twitter</a>
</div>

</footer>
</body>
</html>