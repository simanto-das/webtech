<!DOCTYPE html>
<html>


<body>

  
    
 
   <div>
    <h1>view details</h1>
   <br />
   
      <div>
         <P> UNO CARD GAME
      </P>

         <div>
      <p>price-250 Tk</p>
         </div> 
      </div>
      <br /><br />
      
      <div>
         <button style="margin-top:30px; font-size:120%; type="button" onClick="document.location.href='cartlist.php'">ADD TO CART</button>
         
      </div>


      
         
      </div>
      
   </body>
   </html>