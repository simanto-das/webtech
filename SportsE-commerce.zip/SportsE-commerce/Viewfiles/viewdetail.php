<!DOCTYPE html>
<html>
<head>
  <title>SPORTS-ECOMMERCE</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
  <div style="display:inline-center;">
    <?php include 'header.php' ?>
  </div>
  <div style="display:inline-block;">

    <nav>
       <a style="margin-left:10px; font-size:120%;" href="adminhome.php">Home</a>
      <a style="margin-left:10px; font-size:120%;" href="viewcatagories.php">Categories</a>
      <a style="margin-left:10px; font-size:120%;" href="shop.php">All Shops</a> 
      <a style="margin-left:10px; font-size:120%;" href="View files/signupall.php">Campaign</a>
      <a style="margin-left:10px; font-size:120%;" href="View files/signupall.php">All Products</a> 
      <a style="margin-left:10px; font-size:120%;" href="View files/signupall.php">Brands</a> 
      <a style="margin-left:10px; font-size:120%;" href="View files/login.php">Gift Cards</a>
      <a style="margin-left:10px; font-size:120%;" href="View files/login.php">Customer Accounts</a>
      <a style="margin-left:10px; font-size:120%;" href="chat.php">Chat</a>
    </nav>
  </div>
  <div>
  </div>
<div  style="max-width:1500px; background-color: lightgrey; margin-left:100px; margin-right:100px;">
  <h2 style="text-align: center; margin-top: 30px;">Football Team jersey</h2>
  
  <div>
    <p> <h2 style="margin-left: 100px"> Jersey </h2> </p>
    <pre><img src="l1.png" alt="Juventus Jersey"  style="width: 40%; margin-left: 10px;">
    <p> <h2 style="text-align:left; margin-left: 45px"> Juventus Jersey </h2> </p>
    <div style="margin-left: 60px;padding: 5px">
      <button type="button" onClick="document.location.href='shopdetails.php'">Add products</button> 
    </div>

  </div>

  <div  style="max-width:1000px;  margin-left:20px; margin-right:100px;">
  <h2 style="text-align: center; margin-top: 30px; color: Blue; font-size: 200%">Product Description</h2>

  <h2 style="text-align: left; margin-top: 30px; color: black; font-size: 120%; font-family: helvetica">Sports E-commerce is a sports based e-commerce website. In this website, we tried to put every section e-commerce or sports online market. We tried to make more user friendly feature and we have used simple HTML code and PHP code. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident.</h2>


  </div>
 
 
    
  
<div style="margin-left: 600px;">
  <button style="background-color: tomato"type="button" onClick="document.location.href='viewproducts.php'">View more</button>
</div>  
</div>



<div>
    <?php include 'footer.php' ?>
  </div>
</body>
</html>